﻿//1. Programa que pida el nombre y la edad del usuario, y que muestre un saludo con el nombre del usuario
//, la cantidad de veces de la edad. (Ejemplo: si el nombre es "Luis" y la edad es 24, debe mostrar el saludo: 
//"Hola Luis" 24 veces)
int a;

string b;
Console.WriteLine("Ingrese su nombre");
b = Console.ReadLine();
Console.WriteLine("Ingrese su edad");
a = int.Parse(Console.ReadLine());

//while(a>0)
{
    
    //Console.WriteLine(a+" Hola " +b+" como estas?");
    //a--;
}

do{

    Console.WriteLine(a+".Hola "+b+" como estas?");
    a--;
}while(a>0);

